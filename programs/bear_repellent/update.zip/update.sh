#!/bin/bash

set -e

xargs  -I{} sh -c 'wget --show-progress -O "/home/cap/aicap/extmod/$(basename "{}")" "{}"' < filelist.txt


