#!/bin/bash

set -e

xargs  -I{} sh -c 'wget --show-progress -O "/home/cap/aicap/extmod/$(basename "{}")" "{}"' < filelist.txt
chmod +x /home/cap/aicap/extmod/start.sh
chmod +x /home/cap/aicap/extmod/stop.sh

